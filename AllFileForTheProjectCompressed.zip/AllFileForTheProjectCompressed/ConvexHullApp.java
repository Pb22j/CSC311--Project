import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.io.File;

public class ConvexHullApp {


    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private DrawerPanel drawerPanel;
    private JTextArea upperHullText;
    private JTextArea lowerHullText;
    private JTextArea extremeText;
    private JLabel timeLabel;

    
    private final Color LOGO_BG     = new Color(32, 33, 36);
    private final Color LOGO_PANEL  = new Color(41, 42, 45);
    private final Color TEXT_WHITE  = new Color(232, 234, 237);

    private final Color BTN_GREEN   = new Color(52, 168, 83);
    private final Color BTN_BLUE    = new Color(66, 133, 244);
    private final Color BTN_RED     = new Color(234, 67, 53);
    private final Color BTN_YELLOW  = new Color(251, 188, 4);
    private final Color BTN_PURPLE  = new Color(161, 66, 244);
    private final Color BTN_GRAY    = new Color(95, 99, 104);

    public static void main(String[] args) {
    
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
    
        }

        SwingUtilities.invokeLater(new Runnable() {
             
            public void run() {
                ConvexHullApp app = new ConvexHullApp();
                app.initUI();
            }
        });
    }

    
    public void initUI() {
        frame = new JFrame("CSC311 Convex Hull Project");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

    
        JPanel welcomeScreen = createWelcomeScreen();
        JPanel appScreen = createAppScreen();

        mainPanel.add(welcomeScreen, "WELCOME");
        mainPanel.add(appScreen, "APP");

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    
    private JPanel createWelcomeScreen() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(LOGO_BG);

        
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(20, 20, 20, 20));
        topBar.add(createLogoLabel());
        panel.add(topBar, BorderLayout.NORTH);

        
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);

        JLabel title = new JLabel("CSC311 ConvexHull Project");
        title.setFont(new Font("Segoe UI", Font.BOLD, 42));
        title.setForeground(TEXT_WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Instructor: Dr Mishal Aldekhayel");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        subtitle.setForeground(Color.CYAN);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        
        JPanel btnPanel = new JPanel();
        btnPanel.setOpaque(false);

        JButton btnStart = createButton("    Start Project    ", BTN_GREEN);
        btnStart.setBackground(Color.CYAN);
        btnStart.setForeground(Color.BLACK);

        JButton btnCredits = createButton("    Credits    ", BTN_PURPLE);
        btnCredits.setBackground(Color.LIGHT_GRAY);
        btnCredits.setForeground(Color.BLACK);

        JButton btnExit = createButton("    Exit    ", BTN_RED);

        
        btnStart.addActionListener(e -> cardLayout.show(mainPanel, "APP"));
        btnCredits.addActionListener(e -> showCredits());
        btnExit.addActionListener(e -> System.exit(0));

        btnPanel.add(btnStart);
        btnPanel.add(Box.createHorizontalStrut(20));
        btnPanel.add(btnCredits);
        btnPanel.add(Box.createHorizontalStrut(20));
        btnPanel.add(btnExit);

        center.add(Box.createVerticalGlue());
        center.add(title);
        center.add(Box.createVerticalStrut(10));
        center.add(subtitle);
        center.add(Box.createVerticalStrut(50));
        center.add(btnPanel);
        center.add(Box.createVerticalGlue());

        panel.add(center, BorderLayout.CENTER);

        return panel;
    }

    // ============== MAIN APP SCREEN ==============
    private JPanel createAppScreen() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(LOGO_BG);

        drawerPanel = new DrawerPanel();
        JPanel leftPanel = createControlPanel();
        JPanel centerCanvas = createCanvasPanel();
        JPanel rightPanel = createDashboardPanel();

        panel.add(leftPanel, BorderLayout.WEST);
        panel.add(centerCanvas, BorderLayout.CENTER);
        panel.add(rightPanel, BorderLayout.EAST);

        return panel;
    }


    private JPanel createControlPanel() {
        JPanel controls = new JPanel();
        controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));
        controls.setBackground(LOGO_PANEL);
        controls.setPreferredSize(new Dimension(200, 0));
        controls.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblTitle = new JLabel("<html><b style='color:white;font-size:15px'>Controls</b></html>");

        JButton btnLoad   = createButton("Load Data", Color.CYAN);
        btnLoad.setForeground(Color.BLACK);

        JButton btnBrute  = createButton("Brute Force", Color.GRAY);
        btnBrute.setForeground(Color.BLACK);

        JButton btnQuick  = createButton("Quick Hull", Color.CYAN);
        btnQuick.setForeground(Color.BLACK);

        JButton btnGraham = createButton("Graham Scan", Color.GRAY);
        btnGraham.setForeground(Color.BLACK);

        JButton btnReset  = createButton("Reset", Color.CYAN);
        btnReset.setForeground(Color.BLACK);

        JButton btnBack   = createButton("Back", new Color(60, 60, 60));

        controls.add(lblTitle);
        controls.add(Box.createVerticalStrut(15));
        controls.add(btnLoad);
        controls.add(Box.createVerticalStrut(10));
        controls.add(btnBrute);
        controls.add(Box.createVerticalStrut(10));
        controls.add(btnQuick);
        controls.add(Box.createVerticalStrut(10));
        controls.add(btnGraham);
        controls.add(Box.createVerticalStrut(30));
        controls.add(btnReset);
        controls.add(Box.createVerticalGlue());
        controls.add(btnBack);


        btnLoad.addActionListener(e -> handleLoad());
        btnBrute.addActionListener(e -> runAlgorithm("Brute", new Runnable() {
             
            public void run() {
                drawerPanel.runBruteForce();
            }
        }));
        btnQuick.addActionListener(e -> runAlgorithm("Quick", new Runnable() {
             
            public void run() {
                drawerPanel.runQuickHull();
            }
        }));
        btnGraham.addActionListener(e -> runAlgorithm("Graham", new Runnable() {
             
            public void run() {
                drawerPanel.runGrahamScan();
            }
        }));
        btnReset.addActionListener(e -> handleReset());
        btnBack.addActionListener(e -> cardLayout.show(mainPanel, "WELCOME"));

        return controls;
    }


    private JPanel createCanvasPanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(new LineBorder(Color.DARK_GRAY));
        p.add(drawerPanel, BorderLayout.CENTER);
        return p;
    }


    private JPanel createDashboardPanel() {
        JPanel dashboard = new JPanel();
        dashboard.setLayout(new BoxLayout(dashboard, BoxLayout.Y_AXIS));
        dashboard.setBackground(LOGO_PANEL);
        dashboard.setPreferredSize(new Dimension(250, 0));
        dashboard.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel dashTitle = new JLabel("<html><h2 style='color:white'>Dashboard</h2></html>");

        timeLabel = new JLabel("Time: 0 Millisecond");
        timeLabel.setFont(new Font("Consolas", Font.BOLD, 16));
        timeLabel.setForeground(BTN_GREEN);

        upperHullText = createStatArea("Upper Hull Points");
        lowerHullText = createStatArea("Lower Hull Points");
        extremeText   = createStatArea("Extreme Points");

        dashboard.add(dashTitle);
        dashboard.add(Box.createVerticalStrut(10));
        dashboard.add(timeLabel);
        dashboard.add(Box.createVerticalStrut(20));
        dashboard.add(new JScrollPane(upperHullText));
        dashboard.add(Box.createVerticalStrut(10));
        dashboard.add(new JScrollPane(lowerHullText));
        dashboard.add(Box.createVerticalStrut(10));
        dashboard.add(new JScrollPane(extremeText));

        return dashboard;
    }

    // open file chooser to pick txt file
    private void handleLoad() {
        JFileChooser chooser = new JFileChooser(".");
        int option = chooser.showOpenDialog(frame);
        if (option == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            if (f != null) {
                drawerPanel.loadData(f.getAbsolutePath());
                // when we load new data, reset dashboard
                updateDashboard(0);
            }
        }
    }

    private void handleReset() {
        drawerPanel.clearHull();
        updateDashboard(0);
    }

    private void runAlgorithm(String name, Runnable algo) {
        long start = System.nanoTime();
        algo.run();
        long end = System.nanoTime();
        long diff = end - start;
        updateDashboard(diff);
    }

    private void showCredits() {
        String msg = "ConvexHull Project For CSC311\n\n"
                   + "Instructor:\n"
                   + "Dr Mishal Aldekhayel\n\n"
                   + "Developed by:\n"
                   + "Abdulrahamn Almzeal     Id:444100989\n"
                   + "Mohammed Alwanis        Id:444100734\n"
                   + "Waleed Alnajashi        Id:441101493\n"
                   + "Fahad Alsuhaibani       Id:444102498";

        JOptionPane.showMessageDialog(frame, msg, "Credits", JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateDashboard(long timeNs) {
        timeLabel.setText("Time: " + (timeNs / 1000) + " Millisecond");
        upperHullText.setText(formatIndexes(drawerPanel.upperHullindexs));
        lowerHullText.setText(formatIndexes(drawerPanel.lowerHullindexs));
        extremeText.setText(formatIndexes(drawerPanel.extremePointindexs));
    }

    private String formatIndexes(java.util.List<Integer> indexes) {
        if (indexes == null || indexes.isEmpty()) {
            return "None";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < indexes.size(); i++) {
            int idx = indexes.get(i);
            String coord = drawerPanel.XYList[idx];
            sb.append("P").append(idx).append(": (").append(coord).append(")\n");
        }
        return sb.toString();
    }

   

    private JButton createButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setMaximumSize(new Dimension(180, 40));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btn.setBorderPainted(false);
        return btn;
    }

    private JTextArea createStatArea(String title) {
        JTextArea ta = new JTextArea(5, 15);
        ta.setBackground(new Color(30, 30, 30));
        ta.setForeground(Color.LIGHT_GRAY);

        TitledBorder border = BorderFactory.createTitledBorder(
                new LineBorder(Color.GRAY),
                title,
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Segoe UI", Font.PLAIN, 12),
                Color.WHITE
        );
        ta.setBorder(border);
        ta.setEditable(false);
        return ta;
    }

    
    private JLabel createLogoLabel() {
        JLabel logoLabel = new JLabel() {
             
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                ImageIcon icon = Reader.getLogo("ksu.png");
                if (icon != null) {
                    g.drawImage(icon.getImage(), 1, 1, 220, 80, this);
                } else {
                    g2.setColor(BTN_BLUE);
                    g2.fillOval(25, 35, 220, 80);
                }

                g2.setColor(Color.BLACK);
                g2.setStroke(new BasicStroke(2));
                g2.drawRect(0, 0, getWidth(), getHeight());
            }
        };

        logoLabel.setPreferredSize(new Dimension(220, 80));
        return logoLabel;
    }
}
