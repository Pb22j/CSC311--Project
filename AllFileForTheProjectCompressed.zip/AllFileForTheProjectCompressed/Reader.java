import java.io.*;
import java.util.*;
import java.util.regex.*;
import javax.swing.ImageIcon;

public class Reader {
    
    public static String[] getData(String path) {
        List<String> points = new ArrayList<>();
        
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            Pattern pattern = Pattern.compile("\\(([\\d\\.]+),\\s*([\\d\\.]+)\\)");

            
            while ((line = reader.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);
                
                while (matcher.find()) {
                    
                    String x = matcher.group(1);
                    String y = matcher.group(2);
                    points.add(x + "," + y);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
            return new String[0];
        }
        
        return points.toArray(new String[0]);
    }

    //Image Loader for the Logo
    public static ImageIcon getLogo(String path) {
        File f = new File(path);
        if (f.exists()) {
            return new ImageIcon(path);
        }
        return null;
    }

    public static List<Process> readProcesses(String filePath) {
        throw new UnsupportedOperationException("Unimplemented method 'readProcesses'");
    }
}