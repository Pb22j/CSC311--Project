import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.JPanel;

public class DrawerPanel extends JPanel {

    //Point X,Y Data
    private List<Point> allPoints;
    public String[] XYList;

    //UpperHull, LowerHull, Extreme Points Lists
    public List<Integer> upperHullindexs = new ArrayList<>();
    public List<Integer> lowerHullindexs = new ArrayList<>();
    public List<Integer> extremePointindexs = new ArrayList<>();

    //List for drawing Point of hulls
    private List<Point> upperHullPointsDraw = new ArrayList<>();
    private List<Point> lowerHullPointsDraw = new ArrayList<>();

    // XY axis padding
    private static final int PADDING = 50;
    private int minX = 0, maxX = 1000, minY = 0, maxY = 1000;
    
    //Colors
    private final Color BG_COLOR = new Color(Color.black.getRGB());
    private final Color GRID_COLOR = new Color(Color.DARK_GRAY.getRGB());
    private final Color AXIS_COLOR = new Color(Color.LIGHT_GRAY.getRGB());
    private final Color TEXT_COLOR = new Color(Color.WHITE.getRGB());
    private final Color POINT_COLOR = new Color(Color.CYAN.getRGB());
    
    //Colors of Hulls and Extreme Points
    private final Color UPPER_HULL_COLOR = new Color(Color.BLUE.getRGB()); 
    private final Color LOWER_HULL_COLOR = new Color(Color.green.getRGB());  
    private final Color EXTREME_POINT_COLOR = new Color(Color.red.getRGB()); 
    
  
    public DrawerPanel() {
        //Algorithm DrawerPanel it init objects
        //Time Complexity: O(1)

        this.setBackground(BG_COLOR);
        allPoints = new ArrayList<>();
        XYList = new String[0];
    }

    public void loadData(String path) { 
        //Algorithm loadData it take path and load the points
        //input: String path the txt file path
        //output: load XYList and set data
        //Time Complexity: O(n)

        XYList = Reader.getData(path);
        allPoints = new ArrayList<>();
        clearResults();

        if (XYList != null) {
            parsePointsAndFindBounds();
        }
        repaint();
    }

    private void clearResults() {
        //Algorithm clearResults it clear all hull list and draw list
        //Time Complexity: O(n)

        upperHullindexs.clear();
        lowerHullindexs.clear();
        extremePointindexs.clear();
        upperHullPointsDraw.clear();
        lowerHullPointsDraw.clear();
    }

    public void clearHull() {
        //Algorithm clearHull it clear hulls and repaint
        //Time Complexity: O(n)

        clearResults();
        repaint();
    }

    private void parsePointsAndFindBounds() {
        //Algorithm parsePointsAndFindBounds it parse XYList and find min and max bounds
        //Time Complexity: O(n)

        if (XYList == null || XYList.length == 0) return;
        
        minX = 0; maxX = 1000;
        minY = 0; maxY = 1000;

        for (String s : XYList) {
            try {
                String[] parts = s.split(",");
                double x = Double.parseDouble(parts[0]);
                double y = Double.parseDouble(parts[1]);
                
                if (x < minX) minX = (int)x;
                if (x > maxX) maxX = (int)x;
                if (y < minY) minY = (int)y;
                if (y > maxY) maxY = (int)y;

                allPoints.add(new Point((int)x, (int)y));
            } catch (Exception ignored) {}
        }
        
        if (minX < 0) minX -= 10;
        if (maxX > 1000) maxX += 10;
        if (minY < 0) minY -= 10;
        if (maxY > 1000) maxY += 10;
    }

    // ==========================================
    //            ALGORITHMS SECTION
    // ==========================================

    public void runBruteForce() {
        //Algorithm runBruteForce it find convex hull using brute force
        //Time Complexity: O(n^2) or O(nm)

        if (allPoints.size() < 3) return;
        clearResults();

        int n = allPoints.size();
        int leftMost = 0;
        
        for (int i = 1; i < n; i++) {
            Point p = allPoints.get(i);
            Point l = allPoints.get(leftMost);
            if (p.x < l.x || (p.x == l.x && p.y < l.y)) leftMost = i;
        }

        int p = leftMost;
        int q;
        do {
            extremePointindexs.add(p);
            q = (p + 1) % n;
            for (int i = 0; i < n; i++) {
                if (pointLocation(allPoints.get(p), allPoints.get(i), allPoints.get(q)) == 1) {
                    q = i;
                }
            }
            p = q;
        } while (p != leftMost);

        finishAndSort();
    }

    public void runQuickHull() {
        //Algorithm runQuickHull it compute hull using quick hull
        //Time Complexity: O(n log n)

        if (allPoints.size() < 3) return;
        clearResults();

        PointWithIndex minP = new PointWithIndex(allPoints.get(0), 0);
        PointWithIndex maxP = new PointWithIndex(allPoints.get(0), 0);

        for (int i = 1; i < allPoints.size(); i++) {
            Point p = allPoints.get(i);
            if (p.x < minP.p.x) minP = new PointWithIndex(p, i);
            if (p.x > maxP.p.x) maxP = new PointWithIndex(p, i);
        }

        List<PointWithIndex> hull = new ArrayList<>();
        List<PointWithIndex> upperSet = new ArrayList<>();
        List<PointWithIndex> lowerSet = new ArrayList<>();

        for (int i = 0; i < allPoints.size(); i++) {
            Point p = allPoints.get(i);
            if (i == minP.originalIndex || i == maxP.originalIndex) continue;
            
            int loc = pointLocation(minP.p, maxP.p, p);
            if (loc == 1) upperSet.add(new PointWithIndex(p, i));
            else if (loc == -1) lowerSet.add(new PointWithIndex(p, i));
        }

        hull.add(minP);
        findHullRecursive(minP, maxP, upperSet, hull);
        hull.add(maxP);
        findHullRecursive(maxP, minP, lowerSet, hull);
        
        for(PointWithIndex pi : hull) extremePointindexs.add(pi.originalIndex);
        
        finishAndSort();
    }

    private void findHullRecursive(PointWithIndex A, PointWithIndex B, List<PointWithIndex> set, List<PointWithIndex> hull) {
        //Algorithm findHullRecursive it split set and find hull recursively
        //input: A endpoint, B endpoint, set points
        //output: update hull list
        //Time Complexity: O(n)

        if (set.isEmpty()) return;
        int insertPos = hull.indexOf(B);
        if(insertPos == -1) insertPos = hull.size();

        if (set.size() == 1) {
            hull.add(insertPos, set.get(0));
            return;
        }

        double maxDist = Double.NEGATIVE_INFINITY;
        PointWithIndex furth = null;
        for (PointWithIndex pi : set) {
            double d = distance(A.p, B.p, pi.p);
            if (d > maxDist) { maxDist = d; furth = pi; }
        }
        
        if (furth == null) return;
        hull.add(insertPos, furth);

        List<PointWithIndex> leftAP = new ArrayList<>();
        List<PointWithIndex> leftPB = new ArrayList<>();
        for (PointWithIndex pi : set) {
            if (pi == furth) continue;
            if (pointLocation(A.p, furth.p, pi.p) == 1) leftAP.add(pi);
            if (pointLocation(furth.p, B.p, pi.p) == 1) leftPB.add(pi);
        }
        findHullRecursive(A, furth, leftAP, hull);
        findHullRecursive(furth, B, leftPB, hull);
    }

    public void runGrahamScan() {
        //Algorithm runGrahamScan it compute convex hull using graham scan
        //Time Complexity: O(n log n)

        if (allPoints.size() < 3) return;
        clearResults();

        List<PointWithIndex> indexedPoints = new ArrayList<>();
        for(int i=0; i<allPoints.size(); i++) {
            indexedPoints.add(new PointWithIndex(allPoints.get(i), i));
        }

        PointWithIndex start = getMinY(indexedPoints);
        List<PointWithIndex> sorted = sortPolar(indexedPoints, start);

        Stack<PointWithIndex> stack = new Stack<>();
        stack.push(start);
        stack.push(sorted.get(0));

        for (int i = 1; i < sorted.size(); i++) {
            PointWithIndex top = stack.pop();
            while (!stack.isEmpty() && ccw(stack.peek().p, top.p, sorted.get(i).p) <= 0) {
                top = stack.pop();
            }
            stack.push(top);
            stack.push(sorted.get(i));
        }

        for(PointWithIndex pi : stack) extremePointindexs.add(pi.originalIndex);
        finishAndSort();
    }

    // ==========================================
    //      SORTING & FINISHING LOGIC
    // ==========================================

    private void finishAndSort() {
        //Algorithm finishAndSort it classify upper and lower hull and prepare draw lists
        //Time Complexity: O(n)

        classifyHullPoints();
        bubbleSortindexsByX(upperHullindexs);
        bubbleSortindexsByX(lowerHullindexs);
        
        upperHullPointsDraw.clear();
        for (int i = 0; i < upperHullindexs.size(); i++) {
            int index = upperHullindexs.get(i);
            upperHullPointsDraw.add(getPointFromIndex(index));
        }

        lowerHullPointsDraw.clear();
        for (int i = 0; i < lowerHullindexs.size(); i++) {
            int index = lowerHullindexs.get(i);
            lowerHullPointsDraw.add(getPointFromIndex(index));
        }
        
        repaint();
    }

    private void bubbleSortindexsByX(List<Integer> indexs) {
        //Algorithm bubbleSortindexsByX it sort list by x from small to big
        //Time Complexity: O(n^2)

        int n = indexs.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                
                Point p1 = getPointFromIndex(indexs.get(j));
                Point p2 = getPointFromIndex(indexs.get(j + 1));

                if (p1.x > p2.x) {
                    int temp = indexs.get(j);
                    indexs.set(j, indexs.get(j + 1));
                    indexs.set(j + 1, temp);
                }
            }
        }
    }

    private void classifyHullPoints() {
        //Algorithm classifyHullPoints it split extreme points into upper and lower hull
        //Time Complexity: O(n)

        if (extremePointindexs.isEmpty()) return;

        int minIdx = extremePointindexs.get(0);
        int maxIdx = extremePointindexs.get(0);
        Point minP = getPointFromIndex(minIdx);
        Point maxP = getPointFromIndex(maxIdx);

        for (int idx : extremePointindexs) {
            Point p = getPointFromIndex(idx);
            if (p.x < minP.x) { minP = p; minIdx = idx; }
            if (p.x > maxP.x) { maxP = p; maxIdx = idx; }
        }

        for (int idx : extremePointindexs) {
            if (idx == minIdx || idx == maxIdx) {
                upperHullindexs.add(idx);
                lowerHullindexs.add(idx); 
                continue;
            }
            Point p = getPointFromIndex(idx);
            int loc = pointLocation(minP, maxP, p);
            if (loc > 0) upperHullindexs.add(idx); 
            else lowerHullindexs.add(idx);       
        }
        
        Set<Integer> set = new HashSet<>(upperHullindexs);
        upperHullindexs.clear(); 
        upperHullindexs.addAll(set);

        set = new HashSet<>(lowerHullindexs);
        lowerHullindexs.clear(); 
        lowerHullindexs.addAll(set);
    }

    private Point getPointFromIndex(int i) {
        //Algorithm getPointFromIndex it convert XYList to Point object
        //input: int i the index of XYList
        //output: return Point
        //Time Complexity: O(1)

        String[] parts = XYList[i].split(",");
        return new Point((int)Double.parseDouble(parts[0]), (int)Double.parseDouble(parts[1]));
    }

    private int pointLocation(Point A, Point B, Point P) {
        //Algorithm pointLocation it find orientation of P with line AB
        //input: points A,B,P
        //output: 1 left, 0 collinear, -1 right
        //Time Complexity: O(1)

        double cp = (B.x - A.x) * (P.y - A.y) - (B.y - A.y) * (P.x - A.x);
        if (cp > 0) return 1; 
        if (cp == 0) return 0; 
        return -1;            
    }
    
    private double distance(Point A, Point B, Point C) {
        //Algorithm distance it compute distance from C to line AB
        //input: points A,B,C
        //output: double distance
        //Time Complexity: O(1)

        double ABx = B.x - A.x;
        double ABy = B.y - A.y;
        return Math.abs(ABx * (A.y - C.y) - ABy * (A.x - C.x));
    }

    private static class PointWithIndex {
        //Algorithm PointWithIndex it store point with its index
        //input: Point p, int i index
        //output: object that hold both
        //Time Complexity: O(1)

        Point p; 
        int originalIndex;
        PointWithIndex(Point p, int i) { 
            this.p = p; 
            this.originalIndex = i; 
        }
    }

    private PointWithIndex getMinY(List<PointWithIndex> list) {
        //Algorithm getMinY it find point with minimum Y
        //input: list of points
        //output: return lowest Y point
        //Time Complexity: O(n)

        PointWithIndex min = list.get(0);
        for(PointWithIndex pi : list) {
            if(pi.p.y < min.p.y || (pi.p.y == min.p.y && pi.p.x < min.p.x)) min = pi;
        }
        return min;
    }

    private List<PointWithIndex> sortPolar(List<PointWithIndex> list, PointWithIndex pivot) {
        //Algorithm sortPolar it sort points by angle with pivot
        //input: list and pivot point
        //output: sorted list
        //Time Complexity: O(n log n)

        List<PointWithIndex> copy = new ArrayList<>(list);
        copy.remove(pivot);
        copy.sort((a, b) -> {
            int orient = ccw(pivot.p, a.p, b.p);
            if (orient == 0) {
                double d1 = distSq(pivot.p, a.p);
                double d2 = distSq(pivot.p, b.p);
                return Double.compare(d1, d2);
            }
            return -orient; 
        });
        return copy;
    }

    private int ccw(Point a, Point b, Point c) {
        //Algorithm ccw it test orientation
        //input: 3 points
        //output: -1 0 1
        //Time Complexity: O(1)

        double val = (double)(b.x - a.x)*(c.y - a.y) - (double)(b.y - a.y)*(c.x - a.x);
        if (val < 0) return -1;
        if (val > 0) return 1;
        return 0;
    }

    private double distSq(Point a, Point b) {
        //Algorithm distSq it compute distance squared
        //input: points a,b
        //output: double
        //Time Complexity: O(1)

        return Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2);
    }

    
    protected void paintComponent(Graphics g) {
        //Algorithm paintComponent it draw grid, points, hulls
        //input: Graphics g
        //output: draw everything
        //Time Complexity: O(n)

        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        
        int drawableWidth = w - 2 * PADDING;
        int drawableHeight = h - 2 * PADDING;

        drawGridAndAxes(g2d, w, h, drawableWidth, drawableHeight);

        if (allPoints.isEmpty()) return;

        double rangeX = (maxX - minX) == 0 ? 1 : (maxX - minX);
        double rangeY = (maxY - minY) == 0 ? 1 : (maxY - minY);

        g2d.setColor(POINT_COLOR);
        for (Point p : allPoints) {
            Point s = scale(p, drawableWidth, drawableHeight, rangeX, rangeY, h);
            g2d.fillOval(s.x - 4, s.y - 4, 8, 8);
        }

        if (!upperHullPointsDraw.isEmpty()) {
            g2d.setColor(UPPER_HULL_COLOR);
            g2d.setStroke(new BasicStroke(3f));
            for (int i = 0; i < upperHullPointsDraw.size() - 1; i++) {
                Point p1 = upperHullPointsDraw.get(i);
                Point p2 = upperHullPointsDraw.get(i + 1);
                Point s1 = scale(p1, drawableWidth, drawableHeight, rangeX, rangeY, h);
                Point s2 = scale(p2, drawableWidth, drawableHeight, rangeX, rangeY, h);
                g2d.drawLine(s1.x, s1.y, s2.x, s2.y);
            }
        }

        if (!lowerHullPointsDraw.isEmpty()) {
            g2d.setColor(LOWER_HULL_COLOR);
            g2d.setStroke(new BasicStroke(3f));
            for (int i = 0; i < lowerHullPointsDraw.size() - 1; i++) {
                Point p1 = lowerHullPointsDraw.get(i);
                Point p2 = lowerHullPointsDraw.get(i + 1);
                Point s1 = scale(p1, drawableWidth, drawableHeight, rangeX, rangeY, h);
                Point s2 = scale(p2, drawableWidth, drawableHeight, rangeX, rangeY, h);
                g2d.drawLine(s1.x, s1.y, s2.x, s2.y);
            }
        }

        g2d.setColor(EXTREME_POINT_COLOR);
        for (int idx : extremePointindexs) {
             Point p = getPointFromIndex(idx);
             Point s = scale(p, drawableWidth, drawableHeight, rangeX, rangeY, h);
             g2d.fillOval(s.x - 5, s.y - 5, 10, 10); 
        }
    }

    private void drawGridAndAxes(Graphics2D g2d, int w, int h, int dw, int dh) {
        //Algorithm drawGridAndAxes it draw grid and axis
        //input: g2d and dimensions
        //output: draw grid
        //Time Complexity: O(n)

        g2d.setColor(GRID_COLOR);
        g2d.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, new float[]{9.0f}, 0.0f));
        g2d.drawLine(PADDING, h/2, w-PADDING, h/2);
        g2d.drawLine(w/2, PADDING, w/2, h-PADDING);

        g2d.setStroke(new BasicStroke(2f));
        g2d.setColor(AXIS_COLOR);
        g2d.drawLine(PADDING, PADDING, PADDING, h - PADDING);
        g2d.drawLine(PADDING, h - PADDING, w - PADDING, h - PADDING);

        g2d.setColor(TEXT_COLOR);
        g2d.setFont(new Font("Consolas", Font.PLAIN, 10));

        int step = 100;
        
        for (int i = 0; i <= 1000; i += step) {
            int xPixel = PADDING + (int)((i / 1000.0) * dw);
            int yBase = h - PADDING;
            g2d.drawLine(xPixel, yBase, xPixel, yBase + 5);
            String label = String.valueOf(i);
            int textWidth = g2d.getFontMetrics().stringWidth(label);
            g2d.drawString(label, xPixel - (textWidth / 2), yBase + 20);
        }

        for (int i = 0; i <= 1000; i += step) {
            int yPixel = (h - PADDING) - (int)((i / 1000.0) * dh);
            int xBase = PADDING;
            g2d.drawLine(xBase - 5, yPixel, xBase, yPixel);
            String label = String.valueOf(i);
            int textWidth = g2d.getFontMetrics().stringWidth(label);
            g2d.drawString(label, xBase - 10 - textWidth, yPixel + 4);
        }
    }

    private Point scale(Point p, int dw, int dh, double rx, double ry, int h) {
        //Algorithm scale it scale real point to screen point
        //input: point p
        //output: return scaled point
        //Time Complexity: O(1)

        int x = PADDING + (int)(((p.x - minX) / rx) * dw);
        int y = h - PADDING - (int)(((p.y - minY) / ry) * dh);
        return new Point(x, y);
    }
}
